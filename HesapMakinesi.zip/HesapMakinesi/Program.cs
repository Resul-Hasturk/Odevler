﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HesapMakinesi
{
    class Program
    {
        static void Main(string[] args)
        {
            string islem;
            //double sayi1;
            //double sayi2;
            Console.Write("Yapmak istediğiniz işlem: ");
            islem = Console.ReadLine();
            //Console.Write(islem);

            if (islem == "+")
            {
                Console.Write("1.Sayıyı giriniz: ");
                //double sayi1 = 0;
                double sayi1 = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine(sayi1);

                //double sayi2 = 0;
                Console.Write("2. Sayıyı giriniz: ");
                double sayi2 = Convert.ToDouble(Console.ReadLine());

                //Console.ReadLine();

                double sonuc = sayi1 + sayi2;

                Console.Write("Sonuc: "+ sonuc);

                //Console.ReadLine();
            }
            else if (islem == "-")
            {
                Console.Write("1.Sayıyı giriniz: ");
                //double sayi1 = 0;
                double sayi1 = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine(sayi1);

                //double sayi2 = 0;
                Console.Write("2. Sayıyı giriniz: ");
                double sayi2 = Convert.ToDouble(Console.ReadLine());

                //Console.ReadLine();

                double sonuc = sayi1 - sayi2;

                Console.Write("Sonuc: " + sonuc);
            }
            else if (islem == "/")
            {
                Console.Write("1.Sayıyı giriniz: ");
                //double sayi1 = 0;
                double sayi1 = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine(sayi1);

                //double sayi2 = 0;
                Console.Write("2. Sayıyı giriniz: ");
                double sayi2 = Convert.ToDouble(Console.ReadLine());

                //Console.ReadLine();

                double sonuc = sayi1 / sayi2;

                Console.Write("Sonuc: " + sonuc);
            }
            else if (islem == "*")
            {
                Console.Write("1.Sayıyı giriniz: ");
                //double sayi1 = 0;
                double sayi1 = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine(sayi1);

                //double sayi2 = 0;
                Console.Write("2. Sayıyı giriniz: ");
                double sayi2 = Convert.ToDouble(Console.ReadLine());

                //Console.ReadLine();

                double sonuc = sayi1 * sayi2;

                Console.Write("Sonuc: " + sonuc);

            }

            Console.ReadLine();
        }
    }
}
