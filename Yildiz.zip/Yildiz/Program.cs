﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {

            for (int i = 0; i < 5; i++)
            {

                for (int j = 0; j < i; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine("*"); 
                    }

                for (int c = 4; c > 0; c--)
                {

                    for (int j = 1; j < c; j++)
                    {
                        Console.Write("*");
                    }
                    Console.WriteLine("*");

                }
                Console.ReadLine();
        }
    }
}
